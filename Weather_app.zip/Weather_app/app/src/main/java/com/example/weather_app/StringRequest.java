package com.example.weather_app;

public class StringRequest {
}
